import Link from "next/link";
import {createSupabaseServerClient} from "@/lib/supabase-server";
import {createSupabaseAdminClient} from "@/lib/supabase-admin";
import {isAdminEmail} from "@/lib/authz";
import AdminDashboard from "@/components/AdminDashboard";
export const dynamic="force-dynamic";
export default async function AdminPage(){
 const supabase=await createSupabaseServerClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)return <section className="container auth-box"><h1 className="page-title">Store administration</h1><div className="notice warning">Please sign in first using your administrator email address.</div><Link href="/account" className="button" style={{marginTop:15}}>Sign in</Link></section>;
 if(!isAdminEmail(user.email))return <section className="container auth-box"><h1 className="page-title">Access restricted</h1><div className="notice warning">This account is not listed in the server's ADMIN_EMAILS setting.</div></section>;
 // Admin reads use the service-role client only after server-side identity + allowlist checks.
 const adminDb=createSupabaseAdminClient();
 const {data:products}=await adminDb.from("products").select("*").order("created_at",{ascending:false}).limit(100);
 const {data:orders}=await adminDb.from("orders").select("id,status,payment_status,subtotal_cents,currency,customer_email,created_at").order("created_at",{ascending:false}).limit(100);
 return <section className="container"><h1 className="page-title">Store dashboard</h1><p className="muted">Manage your product catalog and review recent orders.</p><AdminDashboard initialProducts={products||[]} initialOrders={orders||[]}/></section>;
}
