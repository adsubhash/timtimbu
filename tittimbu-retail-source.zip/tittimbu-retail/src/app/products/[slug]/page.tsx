import {notFound} from "next/navigation";
import Link from "next/link";
import {createSupabaseServerClient} from "@/lib/supabase-server";
import {formatMoney} from "@/lib/money";
import AddProductButton from "@/components/AddProductButton";

export const dynamic="force-dynamic";
export default async function ProductPage({params}:{params:{slug:string}}){
 const supabase=await createSupabaseServerClient();
 const {data:p,error}=await supabase.from("products").select("id,name,slug,description,price_cents,category,image_url,stock_quantity,active").eq("slug",params.slug).eq("active",true).maybeSingle();
 if(error||!p)notFound();
 return <section className="container"><p style={{marginTop:25}}><Link href="/">← Back to shop</Link></p><div className="detail-layout"><div className="detail-image">{p.image_url?<img src={p.image_url} alt={p.name}/>:<span>📦</span>}</div><div className="detail-info"><div className="eyebrow">{p.category||"Everyday essentials"}</div><h1>{p.name}</h1><p>{p.description||"A useful find for everyday life."}</p><div className="detail-price">{formatMoney(p.price_cents)}</div><p>{p.stock_quantity>0?`${p.stock_quantity} in stock`:"Currently out of stock"}</p><AddProductButton product={p}/><p className="muted" style={{fontSize:12}}>Secure payment is handled by Stripe Checkout. Final prices and stock are checked again by the server.</p></div></div></section>;
}
