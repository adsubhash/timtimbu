import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import Providers from "./providers";

export const metadata: Metadata = {
  title: "Tittimbu | Everyday shopping, made simple",
  description: "Shop everyday essentials and thoughtful finds at Tittimbu."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>
    <header className="site-header">
      <div className="header-inner">
        <Link href="/" className="brand"><span className="brand-mark">t</span><span>tittimbu<span className="brand-dot">.</span></span></Link>
        <span className="header-tagline">Everyday shopping, made simple</span>
        <nav><Link href="/">Shop</Link><Link href="/cart">Cart</Link><Link href="/account">Account</Link></nav>
      </div>
    </header>
    <Providers><main>{children}</main></Providers>
    <footer className="footer">
      <div><Link href="/" className="footer-brand">tittimbu.</Link><p>Good finds for everyday life.</p></div>
      <div className="footer-links"><Link href="/shipping-returns">Shipping & returns</Link><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link><Link href="/admin">Admin</Link></div>
      <small>© {new Date().getFullYear()} Tittimbu. All rights reserved.</small>
    </footer>
  </body></html>;
}
