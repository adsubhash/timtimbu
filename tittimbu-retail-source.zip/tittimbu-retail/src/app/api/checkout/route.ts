import {NextResponse} from "next/server";
import {getStripe} from "@/lib/stripe";
import {createSupabaseAdminClient} from "@/lib/supabase-admin";

export const runtime="nodejs";
type RequestedItem={productId:string;quantity:number};

export async function POST(request:Request){
 try{
  const body=await request.json();
  const items:RequestedItem[]=body.items;
  if(!Array.isArray(items)||items.length<1||items.length>50) return NextResponse.json({error:"Cart is empty or too large."},{status:400});
  const normalized=new Map<string,number>();
  for(const item of items){
   if(!item||typeof item.productId!=="string"||!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>99) return NextResponse.json({error:"Invalid cart item."},{status:400});
   normalized.set(item.productId,(normalized.get(item.productId)||0)+item.quantity);
  }
  const ids=[...normalized.keys()];
  const db=createSupabaseAdminClient();
  const {data:products,error}=await db.from("products").select("id,name,price_cents,stock_quantity,active").in("id",ids);
  if(error||!products||products.length!==ids.length) return NextResponse.json({error:"One or more products are unavailable."},{status:400});
  for(const p of products){const q=normalized.get(p.id)!;if(!p.active||p.stock_quantity<q)return NextResponse.json({error:`Not enough stock for ${p.name}. Please update your cart.`},{status:409});}
  const stripe=getStripe();
  const site=(process.env.NEXT_PUBLIC_SITE_URL||new URL(request.url).origin).replace(/\/$/,"");
  const {data:order,error:orderError}=await db.from("orders").insert({status:"pending",payment_status:"unpaid",currency:"usd",subtotal_cents:products.reduce((s,p)=>s+p.price_cents*normalized.get(p.id)!,0),customer_email:null,shipping_address:{},metadata:{source:"stripe_checkout"}}).select("id").single();
  if(orderError||!order)return NextResponse.json({error:"Could not create order. Please try again."},{status:500});
  const {error:lineError}=await db.from("order_items").insert(products.map(p=>({order_id:order.id,product_id:p.id,product_name:p.name,unit_price_cents:p.price_cents,quantity:normalized.get(p.id)!})));
  if(lineError){await db.from("orders").delete().eq("id",order.id);return NextResponse.json({error:"Could not create order items."},{status:500});}
  try{
   const session=await stripe.checkout.sessions.create({
    mode:"payment",
    line_items:products.map(p=>({quantity:normalized.get(p.id)!,price_data:{currency:"usd",unit_amount:p.price_cents,product_data:{name:p.name}}})),
    success_url:`${site}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:`${site}/cart?cancelled=1`,
    billing_address_collection:"required",
    shipping_address_collection:{allowed_countries:["US"]},
    allow_promotion_codes:false,
    metadata:{order_id:order.id}
   });
   await db.from("orders").update({stripe_session_id:session.id}).eq("id",order.id);
   return NextResponse.json({url:session.url});
  }catch(e){await db.from("orders").update({status:"cancelled"}).eq("id",order.id);throw e;}
 }catch(e:any){console.error("checkout error",e?.message||e);return NextResponse.json({error:"Checkout could not be started. Check server configuration and try again."},{status:500});}
}
