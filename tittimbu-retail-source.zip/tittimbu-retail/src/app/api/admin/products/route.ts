import {NextResponse} from "next/server";
import {createSupabaseServerClient} from "@/lib/supabase-server";
import {createSupabaseAdminClient} from "@/lib/supabase-admin";
import {isAdminEmail} from "@/lib/authz";

async function authorize(){const s=await createSupabaseServerClient();const {data:{user}}=await s.auth.getUser();return !!user&&isAdminEmail(user.email)}
export async function POST(request:Request){
 if(!await authorize())return NextResponse.json({error:"Unauthorized"},{status:401});
 const b=await request.json();
 const name=String(b.name||"").trim(),slug=String(b.slug||"").trim().toLowerCase(),description=String(b.description||"").trim(),category=String(b.category||"General").trim(),image_url=b.image_url?String(b.image_url).trim():null;
 const price_cents=Number(b.price_cents),stock_quantity=Number(b.stock_quantity);
 if(name.length<2||name.length>120||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)||!Number.isInteger(price_cents)||price_cents<1||price_cents>100000000||!Number.isInteger(stock_quantity)||stock_quantity<0||stock_quantity>1000000)return NextResponse.json({error:"Check product name, URL slug, price (in cents), and stock quantity."},{status:400});
 const db=createSupabaseAdminClient();
 const {data,error}=await db.from("products").insert({name,slug,description,category,image_url,price_cents,stock_quantity,active:true}).select("*").single();
 if(error)return NextResponse.json({error:error.code==="23505"?"That product URL slug already exists.":error.message},{status:400});
 return NextResponse.json({product:data});
}
export async function PATCH(request:Request){
 if(!await authorize())return NextResponse.json({error:"Unauthorized"},{status:401});
 const b=await request.json();if(typeof b.id!=="string")return NextResponse.json({error:"Product id required."},{status:400});
 const updates:any={};
 if(typeof b.active==="boolean")updates.active=b.active;
 if(Number.isInteger(b.stock_quantity)&&b.stock_quantity>=0&&b.stock_quantity<=1000000)updates.stock_quantity=b.stock_quantity;
 if(Number.isInteger(b.price_cents)&&b.price_cents>0&&b.price_cents<=100000000)updates.price_cents=b.price_cents;
 if(!Object.keys(updates).length)return NextResponse.json({error:"No valid changes supplied."},{status:400});
 const db=createSupabaseAdminClient();const {data,error}=await db.from("products").update(updates).eq("id",b.id).select("*").single();
 if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({product:data});
}
