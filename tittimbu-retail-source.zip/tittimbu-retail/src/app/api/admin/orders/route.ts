import {NextResponse} from "next/server";
import {createSupabaseServerClient} from "@/lib/supabase-server";
import {createSupabaseAdminClient} from "@/lib/supabase-admin";
import {isAdminEmail} from "@/lib/authz";
export async function PATCH(request:Request){
 const s=await createSupabaseServerClient();const {data:{user}}=await s.auth.getUser();
 if(!user||!isAdminEmail(user.email))return NextResponse.json({error:"Unauthorized"},{status:401});
 const b=await request.json();const allowed=["processing","shipped","delivered","cancelled","refunded"];
 if(typeof b.id!=="string"||!allowed.includes(b.status))return NextResponse.json({error:"Invalid order update."},{status:400});
 const db=createSupabaseAdminClient();
 const {data:order,error:readError}=await db.from("orders").select("id,payment_status,status").eq("id",b.id).single();
 if(readError||!order)return NextResponse.json({error:"Order not found."},{status:404});
 if(b.status==="cancelled"&&order.payment_status==="paid")return NextResponse.json({error:"Paid orders cannot be cancelled here. Refund through Stripe first."},{status:409});
 if(b.status==="refunded"&&order.payment_status!=="refunded")return NextResponse.json({error:"Process the refund in Stripe first; payment status is updated by webhook."},{status:409});
 const {error}=await db.from("orders").update({status:b.status}).eq("id",b.id);
 if(error)return NextResponse.json({error:error.message},{status:400});
 return NextResponse.json({ok:true});
}
