import {NextResponse} from "next/server";
import Stripe from "stripe";
import {getStripe} from "@/lib/stripe";
import {createSupabaseAdminClient} from "@/lib/supabase-admin";

export const runtime="nodejs";
export async function POST(request:Request){
 const signature=request.headers.get("stripe-signature");
 const secret=process.env.STRIPE_WEBHOOK_SECRET;
 if(!signature||!secret)return NextResponse.json({error:"Webhook configuration missing."},{status:400});
 const raw=await request.text();
 let event:Stripe.Event;
 try{event=getStripe().webhooks.constructEvent(raw,signature,secret);}
 catch(err){return NextResponse.json({error:"Invalid webhook signature."},{status:400});}
 const db=createSupabaseAdminClient();
 try{
  if(event.type==="checkout.session.completed"||event.type==="checkout.session.async_payment_succeeded"){
   const session=event.data.object as Stripe.Checkout.Session;
   if(session.payment_status!=="paid")return NextResponse.json({received:true});
   const orderId=session.metadata?.order_id;
   if(!orderId)return NextResponse.json({error:"Missing order metadata."},{status:400});
   // Atomic database function prevents duplicate webhook deliveries from double-decrementing stock.
   const paymentIntentId=typeof session.payment_intent==="string"?session.payment_intent:null;
   const {error}=await db.rpc("complete_paid_order",{p_order_id:orderId,p_session_id:session.id,p_payment_intent_id:paymentIntentId,p_customer_email:session.customer_details?.email||null,p_shipping_address:session.shipping_details?.address||{}});
   if(error){console.error("complete_paid_order failed",error.message);return NextResponse.json({error:"Could not complete order."},{status:500});}
  }else if(event.type==="checkout.session.expired"){
   const session=event.data.object as Stripe.Checkout.Session;
   if(session.metadata?.order_id)await db.from("orders").update({status:"cancelled"}).eq("id",session.metadata.order_id).eq("payment_status","unpaid");
  }else if(event.type==="charge.refunded"){
   const charge=event.data.object as Stripe.Charge;
   const sessionId=typeof charge.payment_intent==="string"?charge.payment_intent:null;
   if(sessionId){
    const {data:session}=await db.from("orders").select("id").eq("stripe_payment_intent_id",sessionId).maybeSingle();
    if(session)await db.from("orders").update({payment_status:"refunded",status:"refunded"}).eq("id",session.id);
   }
  }
  return NextResponse.json({received:true});
 }catch(err){console.error("stripe webhook error",err);return NextResponse.json({error:"Webhook handler failed."},{status:500});}
}
