"use client";
import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatMoney } from "@/lib/money";
import { useState } from "react";

export default function CartPage(){
 const {items,changeQty,removeItem}=useCart();
 const [busy,setBusy]=useState(false);
 const [error,setError]=useState("");
 const subtotal=items.reduce((s,i)=>s+i.price_cents*i.quantity,0);
 async function checkout(){
  setBusy(true);setError("");
  try{
   const res=await fetch("/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:items.map(i=>({productId:i.id,quantity:i.quantity}))})});
   const data=await res.json();
   if(!res.ok)throw new Error(data.error||"Could not start checkout.");
   window.location.href=data.url;
  }catch(e:any){setError(e.message||"Checkout failed. Please try again.");setBusy(false);}
 }
 return <section className="container"><h1 className="page-title">Your cart</h1><p className="muted">Review your items before secure checkout.</p>
 {items.length===0?<div className="empty"><div className="emoji">🛒</div><h3>Your cart is waiting</h3><p>Find something useful for your day.</p><Link className="button" href="/">Continue shopping</Link></div>:
 <div className="content-layout" style={{marginTop:25}}><div className="panel">
 {items.map(i=><div className="cart-line" key={i.id}><div className="cart-thumb">{i.image_url?<img src={i.image_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:12}}/>:"📦"}</div><div><h3>{i.name}</h3><div className="muted">{formatMoney(i.price_cents)} each</div><div className="quantity"><button onClick={()=>changeQty(i.id,i.quantity-1)} aria-label="Decrease quantity">−</button><span>{i.quantity}</span><button onClick={()=>changeQty(i.id,i.quantity+1)} disabled={i.quantity>=i.stock_quantity} aria-label="Increase quantity">+</button></div><button className="remove" onClick={()=>removeItem(i.id)}>Remove</button></div><strong>{formatMoney(i.price_cents*i.quantity)}</strong></div>)}
 </div><aside className="panel"><h2>Order summary</h2><div className="summary-row"><span>Subtotal</span><strong>{formatMoney(subtotal)}</strong></div><div className="summary-row"><span>Shipping</span><span>Calculated at checkout</span></div><div className="summary-row"><span>Tax</span><span>Calculated if configured</span></div><div className="summary-row summary-total"><span>Subtotal</span><span>{formatMoney(subtotal)}</span></div><p className="muted" style={{fontSize:12,lineHeight:1.5}}>Final shipping and any applicable taxes are shown before payment by the configured checkout workflow.</p>{error&&<div className="notice warning">{error}</div>}<button className="button full" onClick={checkout} disabled={busy}>{busy?"Connecting to secure checkout…":"Continue to secure checkout →"}</button><Link className="button secondary full" href="/">Continue shopping</Link></aside></div>}
 </section>;
}
