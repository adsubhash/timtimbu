import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase-server";
import { formatMoney } from "@/lib/money";
import ProductBrowser from "@/components/ProductBrowser";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let products: any[] = [];
  let error = "";
  try {
    const supabase = await createSupabaseServerClient();
    const result = await supabase.from("products")
      .select("id,name,slug,description,price_cents,category,image_url,stock_quantity,active")
      .eq("active", true).order("created_at", { ascending: false }).limit(100);
    if (result.error) error = "Connect your Supabase project and run the database schema to load products.";
    else products = result.data || [];
  } catch {
    error = "Set up Supabase environment variables to load your product catalog.";
  }

  return <>
    <section className="hero">
      <div>
        <div className="eyebrow">Welcome to Tittimbu</div>
        <h1>Good finds for your everyday life.</h1>
        <p>Discover useful essentials, thoughtful picks, and little things that make daily life better.</p>
        <a href="#shop" className="button">Explore the collection <span>→</span></a>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="hero-circle">🛍️</div>
        <div className="floating-tag tag-one">✨ Thoughtful finds</div>
        <div className="floating-tag tag-two">🌿 Everyday essentials</div>
      </div>
    </section>
    <section className="container" id="shop">
      <div className="section-head"><div><div className="eyebrow">Our collection</div><h2>Shop the essentials</h2><p>Browse our current collection of products.</p></div></div>
      {error ? <div className="notice warning">{error}<p>Setup instructions are in README.md.</p></div> :
        <ProductBrowser products={products} />}
      <div style={{marginTop:30}} className="notice">New to Tittimbu? Product availability and prices are confirmed at checkout. Shipping and applicable taxes are calculated before payment.</div>
    </section>
  </>;
}
