"use client";
import {createContext,useContext,useEffect,useMemo,useState} from "react";
type CartItem={id:string;name:string;slug:string;price_cents:number;image_url:string|null;stock_quantity:number;quantity:number};
type NewItem=Omit<CartItem,"quantity">;
type CartContextType={items:CartItem[];addItem:(p:NewItem)=>void;changeQty:(id:string,qty:number)=>void;removeItem:(id:string)=>void;clear:()=>void};
const Context=createContext<CartContextType|null>(null);
export function CartProvider({children}:{children:React.ReactNode}){
 const [items,setItems]=useState<CartItem[]>([]);
 const [ready,setReady]=useState(false);
 useEffect(()=>{try{const saved=localStorage.getItem("tittimbu-cart-v1");if(saved)setItems(JSON.parse(saved));}catch{}setReady(true)},[]);
 useEffect(()=>{if(ready)localStorage.setItem("tittimbu-cart-v1",JSON.stringify(items))},[items,ready]);
 const value=useMemo<CartContextType>(()=>({
  items,
  addItem:(p)=>setItems(old=>{const found=old.find(x=>x.id===p.id);if(found)return old.map(x=>x.id===p.id?{...x,quantity:Math.min(x.quantity+1,p.stock_quantity)}:x);return p.stock_quantity>0?[...old,{...p,quantity:1}]:old}),
  changeQty:(id,qty)=>setItems(old=>old.map(x=>x.id===id?{...x,quantity:Math.min(x.stock_quantity,Math.max(1,qty))}:x)),
  removeItem:(id)=>setItems(old=>old.filter(x=>x.id!==id)),
  clear:()=>setItems([])
 }),[items]);
 return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useCart(){const value=useContext(Context);if(!value)throw new Error("useCart must be used inside CartProvider");return value}
