"use client";
import {CartProvider} from "./CartProvider";
export default function CartShell({children}:{children:React.ReactNode}){return <CartProvider>{children}</CartProvider>}
