"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { formatMoney } from "@/lib/money";
import { useCart } from "@/components/CartProvider";

type Product = {id:string;name:string;slug:string;description:string|null;price_cents:number;category:string|null;image_url:string|null;stock_quantity:number;active:boolean};
export default function ProductBrowser({products}:{products:Product[]}) {
  const [query,setQuery] = useState("");
  const [category,setCategory] = useState("All");
  const {addItem} = useCart();
  const categories = ["All", ...Array.from(new Set(products.map(p=>p.category).filter(Boolean) as string[])).sort()];
  const filtered = useMemo(()=>products.filter(p=>(category==="All"||p.category===category)&&`${p.name} ${p.description||""} ${p.category||""}`.toLowerCase().includes(query.toLowerCase())),[products,query,category]);
  return <>
    <div className="search-row"><input className="search-input" aria-label="Search products" placeholder="Search products, categories, and more..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
    <div className="category-row">{categories.map(c=><button key={c} className={`chip ${category===c?"active":""}`} onClick={()=>setCategory(c)}>{c}</button>)}</div>
    {filtered.length===0?<div className="empty"><div className="emoji">🛍️</div><h3>No products found</h3><p>Add products from your admin dashboard or try another search.</p></div>:
      <div className="product-grid">{filtered.map(p=><article className="product-card" key={p.id}>
        <Link href={`/products/${p.slug}`} className="product-image">{p.image_url?<img src={p.image_url} alt={p.name}/>:<span>📦</span>}</Link>
        <div className="product-content"><div className="product-category">{p.category||"Everyday"}</div><Link href={`/products/${p.slug}`}><h3>{p.name}</h3></Link><div className="product-description">{p.description||"A useful find for everyday life."}</div>
          <div className="product-bottom"><span className="price">{formatMoney(p.price_cents)}</span><button className="small-button" disabled={p.stock_quantity<1} onClick={()=>addItem({id:p.id,name:p.name,slug:p.slug,price_cents:p.price_cents,image_url:p.image_url,stock_quantity:p.stock_quantity})}>{p.stock_quantity<1?"Sold out":"Add +"}</button></div>
          <div className="stock-note">{p.stock_quantity>0?`${p.stock_quantity} available`:"Currently unavailable"}</div>
        </div></article>)}</div>}
  </>;
}
