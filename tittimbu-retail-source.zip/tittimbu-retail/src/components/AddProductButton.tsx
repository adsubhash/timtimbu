"use client";
import {useCart} from "@/components/CartProvider";
export default function AddProductButton({product}:{product:any}){const {addItem}=useCart();return <button className="button" disabled={product.stock_quantity<1} onClick={()=>addItem(product)}>{product.stock_quantity<1?"Sold out":"Add to cart"}</button>}
