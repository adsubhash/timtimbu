export function isAdminEmail(email?:string|null){
 if(!email)return false;
 const allowed=(process.env.ADMIN_EMAILS||"").split(",").map(x=>x.trim().toLowerCase()).filter(Boolean);
 return allowed.includes(email.toLowerCase());
}
