import { createClient } from "@supabase/supabase-js";

/**
 * SERVER ONLY. Never import this module into a client component.
 * Service role bypasses RLS; use only in trusted server routes/webhooks.
 */
export function createSupabaseAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Server-side Supabase service role key is missing.");
  return createClient(url, key, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}
