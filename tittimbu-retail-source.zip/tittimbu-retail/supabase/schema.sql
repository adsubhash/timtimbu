-- Tittimbu retail schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text,
  category text not null default 'General',
  image_url text,
  price_cents integer not null check (price_cents > 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'pending' check (status in ('pending','processing','shipped','delivered','cancelled','refunded')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','paid','refunded','failed')),
  currency text not null default 'usd',
  subtotal_cents integer not null check (subtotal_cents >= 0),
  customer_email text,
  shipping_address jsonb not null default '{}'::jsonb,
  stripe_session_id text unique,
  stripe_payment_intent_id text unique,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price_cents integer not null check (unit_price_cents > 0),
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_active_category_idx on public.products(active, category);
create index if not exists products_name_idx on public.products using gin (to_tsvector('english', name));
create index if not exists orders_created_at_idx on public.orders(created_at desc);
create index if not exists order_items_order_id_idx on public.order_items(order_id);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.profiles enable row level security;

-- Public can only read active product listings. Writes are through trusted server routes.
drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products
  for select to anon, authenticated using (active = true);

-- A signed-in user can only read/update their own profile.
drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- No direct customer policies on orders/order_items. All order writes and admin reads
-- are performed through server routes using the service-role key after authorization.

-- Atomic, idempotent payment completion: lock order and products, validate stock,
-- decrement inventory exactly once, and mark order paid in a single transaction.
create or replace function public.complete_paid_order(
  p_order_id uuid,
  p_session_id text,
  p_payment_intent_id text,
  p_customer_email text,
  p_shipping_address jsonb
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders%rowtype;
  line record;
  current_stock integer;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'Order not found'; end if;

  -- Duplicate Stripe event delivery: already completed means no further stock changes.
  if o.payment_status = 'paid' then return; end if;
  if o.status = 'cancelled' then raise exception 'Cannot complete cancelled order'; end if;

  for line in
    select oi.product_id, oi.quantity, oi.product_name
    from public.order_items oi where oi.order_id = p_order_id
    order by oi.product_id
  loop
    if line.product_id is null then raise exception 'Product no longer available'; end if;
    select stock_quantity into current_stock
      from public.products where id = line.product_id and active = true for update;
    if not found or current_stock < line.quantity then
      raise exception 'Insufficient stock for %', line.product_name;
    end if;
  end loop;

  for line in
    select oi.product_id, oi.quantity
    from public.order_items oi where oi.order_id = p_order_id
    order by oi.product_id
  loop
    update public.products set stock_quantity = stock_quantity - line.quantity, updated_at = now()
      where id = line.product_id;
  end loop;

  update public.orders
    set status = 'processing',
        payment_status = 'paid',
        stripe_session_id = p_session_id,
        stripe_payment_intent_id = p_payment_intent_id,
        customer_email = p_customer_email,
        shipping_address = coalesce(p_shipping_address, '{}'::jsonb),
        updated_at = now()
    where id = p_order_id;
end;
$$;

revoke all on function public.complete_paid_order(uuid,text,text,text,jsonb) from public, anon, authenticated;
grant execute on function public.complete_paid_order(uuid,text,text,text,jsonb) to service_role;

-- Optional starter demo products. Remove these rows if you prefer a blank catalog.
insert into public.products(name,slug,description,category,price_cents,stock_quantity,active)
values
 ('Everyday Canvas Tote','everyday-canvas-tote','A reusable tote for errands, shopping, and daily essentials.','Accessories',1499,20,true),
 ('Insulated Travel Bottle','insulated-travel-bottle','A simple insulated bottle for work, travel, and everyday hydration.','Home & Living',2199,15,true),
 ('Desk Organizer Tray','desk-organizer-tray','Keep small desk essentials tidy and easy to find.','Home & Living',1299,12,true),
 ('Soft Everyday Throw','soft-everyday-throw','A cozy throw for a sofa, reading chair, or quiet evening.','Home & Living',2899,8,true)
on conflict (slug) do nothing;
