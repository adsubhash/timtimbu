# Tittimbu.com — Retail Store Starter

This project is a practical starter for a single-owner retail store with up to 100 products. It includes a responsive storefront, search/category filtering, product pages, a local cart, Supabase-backed catalog, Stripe Checkout session creation, a Stripe webhook, basic customer sign-up/sign-in, and an email-allowlisted admin dashboard.

**This is not certified or fully launch-ready commerce software.** Before accepting live payments, complete the production checklist at the end of this file. In particular, configure real tax/shipping calculation, customer order history, refunds, email notifications, monitoring, and end-to-end security tests.

## 1. Accounts and tools

- Node.js LTS: https://nodejs.org/
- Supabase: https://supabase.com/
- Stripe: https://stripe.com/
- GitHub: https://github.com/
- Vercel: https://vercel.com/
- Domain registrar for `tittimbu.com` (domain purchase is separate)

Start in Stripe **test mode**. Do not enter live payment credentials until the test workflow passes.

## 2. Run locally

1. Extract the ZIP and open the `tittimbu-retail` folder in VS Code.
2. Open a terminal in that folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Fill in the environment variables described below.
6. In Supabase Dashboard → SQL Editor, paste and run `supabase/schema.sql`.
7. Run `npm run dev`.
8. Visit http://localhost:3000.

## 3. Supabase setup

1. Create a Supabase project.
2. In Project Settings → API, copy the Project URL and anon/public key into:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Copy the **service_role** key into `SUPABASE_SERVICE_ROLE_KEY`. It is server-only and bypasses row-level security. Never put it in a `NEXT_PUBLIC_` variable, client component, GitHub, screenshot, or public document.
4. Run `supabase/schema.sql` in SQL Editor.
5. In Authentication → URL Configuration, set the Site URL to your local URL during development and your real HTTPS domain in production. Add appropriate redirect URLs.
6. If enabling email confirmation, configure Supabase email delivery and templates. Default provider limits may be unsuitable for a commercial store.

The SQL creates products, orders, order_items, profiles, row-level security policies, and an atomic/idempotent payment-completion function. Product inserts/updates and order operations use server routes.

## 4. Stripe test setup

1. Create a Stripe account and use test mode.
2. Copy the test secret key into `STRIPE_SECRET_KEY` (starts with `sk_test_`).
3. For local webhook testing, install Stripe CLI from https://docs.stripe.com/stripe-cli and authenticate it.
4. Start the app (`npm run dev`) and run this in a second terminal:

   `stripe listen --forward-to localhost:3000/api/stripe-webhook`

5. Copy the webhook signing secret printed by the CLI (starts with `whsec_`) into `STRIPE_WEBHOOK_SECRET`.
6. Restart the Next.js dev server after changing `.env.local`.
7. Place a test order and use a Stripe test card from Stripe's official testing documentation: https://docs.stripe.com/testing
8. Verify in Supabase that payment_status becomes `paid`, order status becomes `processing`, and inventory decreases only once.

For production, create a Stripe webhook endpoint at:
`https://YOUR_DOMAIN/api/stripe-webhook`
Subscribe to:
- `checkout.session.completed`
- `checkout.session.async_payment_succeeded`
- `checkout.session.expired`
- `charge.refunded`

Set the endpoint's signing secret as `STRIPE_WEBHOOK_SECRET` in your production host. Test refunds and failure cases. The starter's refund webhook needs production verification and may need adjustment for the payment-intent mapping used by your Stripe configuration.

## 5. Admin dashboard

1. Set `ADMIN_EMAILS=your-real-email@example.com` in `.env.local`.
2. Create an account at `/account` using that exact email.
3. Confirm the email if confirmation is enabled, then sign in.
4. Open `/admin`.
5. Add products using a unique URL slug such as `blue-water-bottle`. Price is entered in dollars; server stores integer cents.
6. Use a public HTTPS image URL for the image field, or add Supabase Storage upload functionality before managing images at scale.

For production, set `ADMIN_EMAILS` as a server environment variable in Vercel too. Do not add it with a `NEXT_PUBLIC_` prefix.

## 6. Deploy

1. Create a private GitHub repository and push this project.
2. In Vercel, import that repository.
3. Add the same environment variables in Vercel → Project Settings → Environment Variables.
4. Set `NEXT_PUBLIC_SITE_URL=https://tittimbu.com`.
5. Deploy and test the Vercel preview before changing DNS.
6. Add `tittimbu.com` and `www.tittimbu.com` to Vercel's domain settings and follow the exact DNS records Vercel displays.
7. Set Supabase Auth Site URL and redirect URLs to the final HTTPS domain.
8. Configure Stripe's production webhook URL and secret.
9. Test a small real transaction only after all production checks are complete.

## 7. Environment variable reference

- `NEXT_PUBLIC_SUPABASE_URL`: Supabase project URL; safe to expose.
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: public/anon key; database RLS must be correct.
- `SUPABASE_SERVICE_ROLE_KEY`: secret server key; never expose to browser.
- `STRIPE_SECRET_KEY`: Stripe secret API key; server only.
- `STRIPE_WEBHOOK_SECRET`: webhook signature secret; server only.
- `NEXT_PUBLIC_SITE_URL`: canonical base URL.
- `ADMIN_EMAILS`: comma-separated admin allowlist; server only.

## 8. Production launch checklist

Do not advertise this starter as a finished production marketplace until the following are done:

- [ ] Confirm legal business name, support email, mailing address, privacy policy, terms, shipping/returns/refund policies.
- [ ] Configure sales tax calculations appropriate to your business and jurisdictions; do not assume Stripe Checkout automatically calculates all required taxes.
- [ ] Configure real shipping methods/rates and verify the final shipping amount before payment.
- [ ] Implement authenticated customer order history and secure order lookup.
- [ ] Implement order confirmation, shipping notifications, return/refund workflows and customer support.
- [ ] Add rate limiting, bot/fraud controls, logging, alerting, backups, recovery drills and dependency updates.
- [ ] Review Supabase RLS and server endpoints with a security professional.
- [ ] Confirm inventory race conditions: this starter checks stock before payment and decrements at successful payment. For a production launch, add inventory reservation/expiration or a transactional stock-hold design to avoid overselling when two customers buy the final unit at once.
- [ ] Add image upload/validation and image optimization.
- [ ] Test desktop, mobile, keyboard accessibility, checkout cancellation, duplicate webhooks, failed payments, low stock and refunds.
- [ ] Review applicable privacy, consumer protection, accessibility, sales tax and business-registration requirements with qualified professionals.
- [ ] Switch to Stripe live mode only after successful end-to-end testing.

## 9. Current scope limitations

- One store owner; no multi-vendor marketplace.
- Cart is stored in the customer's browser; checkout revalidates IDs, price and stock on the server.
- Stripe Checkout collects a US shipping address, but this starter does not calculate shipping/tax or create shipping labels.
- Basic account sign-up/sign-in is included; customer order history and password recovery UI are not yet complete.
- Admin uses an email allowlist and server-side route checks; configure it carefully and use strong account security.
- No live payment credentials or external accounts are included.
